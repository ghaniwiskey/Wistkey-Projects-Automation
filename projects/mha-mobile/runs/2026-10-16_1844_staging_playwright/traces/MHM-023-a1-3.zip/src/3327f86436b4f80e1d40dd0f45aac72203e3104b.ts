import { test, expect, MOBILE_ROLES, blankable, unique } from '../../fixtures/pages.fixture';
import type { HomeScreen } from '../../pages/mobile/home.screen';
import type { RegistrationForm, RegistrationScreen } from '../../pages/mobile/registration.screen';
import type { WebAsset, WebAssetPage } from '../../pages/web/web-asset.page';

// Test cases: projects/mha-mobile/cases/registration/MHM-013-*.md, MHM-023-*.md
// Data comes from the phone: the first PROGRESS asset its Register Asset list offers (UAT 2026-10-16:
// 51 in 332140). Candidate cost centres are those MHA web lists PROGRESS assets for (Agency Admin sees
// every unit; the web LOGS1 role does not cover 332140), tried on the phone until one has a list.
// Completing a registration cannot be undone, so MHM-013 uses one asset up per run.
test.use({ webRole: 'agency-admin' });

const LOGS1 = MOBILE_ROLES.logs1;

type Found = { costCentre: string; asset: WebAsset };

/**
 * Phone: LOGS1 on each cost centre that has PROGRESS assets on MHA web (and that the Switch Role panel
 * offers) until Asset Registration lists some; the first listed asset that fits (with location remarks
 * when asked) is read on MHA web. Leaves the phone on the Register Asset list. Skips when none fits.
 */
async function phoneProgressAsset(
  mobileHome: HomeScreen,
  registrationScreen: RegistrationScreen,
  webAssetPage: WebAssetPage,
  opts: { withRemarks?: boolean } = {},
): Promise<Found> {
  const candidates = await webAssetPage.costCentresWithStatus('PROGRESS');
  await mobileHome.openSwitch();
  await mobileHome.pickRole(LOGS1);
  const offered = await mobileHome.costCentreOptions();
  await mobileHome.closeSwitch();
  const tried: string[] = [];
  for (const costCentre of candidates.filter((c) => offered.includes(c))) {
    tried.push(costCentre);
    await mobileHome.switchTo(LOGS1, costCentre);
    await mobileHome.openTile('Asset Registration');
    await registrationScreen.expectList();
    // Only a few, to stay inside the ~10-minute mobile session (BUG-001).
    for (const id of (await registrationScreen.listedAssets()).slice(0, 3)) {
      await webAssetPage.gotoListing();
      await webAssetPage.openAsset(id);
      const asset = await webAssetPage.readAsset();
      if (!opts.withRemarks || blankable(asset.remarks)) return { costCentre, asset };
    }
    await registrationScreen.close();
    await mobileHome.expectLoaded();
  }
  test.skip(
    true,
    `The phone's Asset Registration (${LOGS1}) lists no PROGRESS asset${opts.withRemarks ? ' with location remarks' : ''} in ${tried.join(', ') || 'any cost centre'} (web PROGRESS units: ${candidates.join(', ')}). Half-register an asset on web in a unit where the officer is LOGS1.`,
  );
  throw new Error('unreachable');
}

test('MHM-013: asset registration completes a progress asset from the phone @regression @writes', async ({
  mobileHome,
  registrationScreen,
  webAssetPage,
}) => {
  test.setTimeout(12 * 60_000);
  let found: Found | undefined;
  await test.step(`1. Phone: ${LOGS1}, Asset Registration lists a PROGRESS asset; MHA web: its location`, async () => {
    found = await phoneProgressAsset(mobileHome, registrationScreen, webAssetPage);
  });
  const { asset, costCentre } = found as Found;
  expect(asset.status).toBe('PROGRESS');
  const newRoom = `R${unique().slice(-4).toUpperCase()}`; // Room No holds 5 characters
  // The form does not pre-fill the remarks and saving clears them (BUG-004), so they are typed as they are.
  const remarks = blankable(asset.remarks);

  let form: RegistrationForm | undefined;
  await test.step(`2. Open ${asset.id} (${costCentre}): the form pre-fills the asset's postal code, block, level and room`, async () => {
    await registrationScreen.open(asset.id);
    form = await registrationScreen.readForm();
    expect(form.postalCode).toBe(asset.postalCode);
    expect(blankable(form.block, 'Block')).toBe(blankable(asset.block));
    expect(blankable(form.level, 'Level')).toBe(blankable(asset.level));
    expect(blankable(form.room, 'Room')).toBe(blankable(asset.roomNo));
  });
  await test.step(`2. Room ${newRoom}, remarks as they are, one photo, Save`, async () => {
    await registrationScreen.setField(registrationScreen.room, newRoom);
    await registrationScreen.setField(registrationScreen.remarks, remarks);
    await registrationScreen.uploadNewestPhoto();
    await registrationScreen.save();
    expect(await registrationScreen.listedAssets()).not.toContain(asset.id);
  });

  await test.step('3. MHA web: the asset is AVAILABLE in the new room with the photo, the rest unchanged', async () => {
    await webAssetPage.gotoListing();
    await webAssetPage.openAsset(asset.id);
    expect(await webAssetPage.hasDefaultPhoto()).toBe(true);
    const after = await webAssetPage.readAsset();
    expect(after.status).toBe('AVAILABLE');
    expect(after.roomNo).toBe(newRoom);
    expect({ postalCode: after.postalCode, block: after.block, level: after.level, remarks: after.remarks }).toEqual({
      postalCode: asset.postalCode,
      block: asset.block,
      level: asset.level,
      remarks: asset.remarks,
    });
  });
});

test('MHM-023: asset registration form pre-fills the asset\'s location remarks @regression', async ({
  mobileHome,
  registrationScreen,
  webAssetPage,
}) => {
  test.fail(true, 'BUG-004: the Register Asset form shows Remarks empty ("(Optional)") and saving clears the asset\'s remarks');
  test.setTimeout(10 * 60_000);
  let found: Found | undefined;
  await test.step('1. Phone: Asset Registration lists a PROGRESS asset that has location remarks on MHA web', async () => {
    found = await phoneProgressAsset(mobileHome, registrationScreen, webAssetPage, { withRemarks: true });
  });
  const { asset } = found as Found;
  await test.step(`2. Open ${asset.id} (no Save): Remarks shows "${asset.remarks}"`, async () => {
    await registrationScreen.open(asset.id);
    const form = await registrationScreen.readForm();
    await registrationScreen.leaveForm();
    expect(form.remarks).toBe(asset.remarks);
  });
});
